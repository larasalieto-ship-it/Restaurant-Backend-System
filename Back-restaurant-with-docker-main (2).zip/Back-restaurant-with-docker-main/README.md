# Restaurant Backend System 🍽️🍔

Este es el backend oficial del sistema de gestión de restaurantes, construido con una arquitectura moderna en **Rust** orientada a la concurrencia, con soporte para comunicación en tiempo real y desplegado a través de **Docker**.

## 🛠️ Tecnologías Utilizadas

- **Lenguaje Principal:** Rust 🦀
- **Framework Web:** [Axum](https://github.com/tokio-rs/axum) (Asíncrono y ultra rápido).
- **Base de Datos:** PostgreSQL 16 (Interacción mediante `sqlx` en Rust).
- **WebSockets:** Implementado nativamente sobre Axum + Tokio para notificaciones en tiempo real (estado de órdenes, mesas, congestión en cocina).
- **Orquestación:** Docker y Docker Compose para levantar fácilmente tanto la base de datos como el servicio de forma unificada.

## 🏗️ Arquitectura y Conexiones

El sistema está definido en `docker-compose.yml` y se compone de dos contenedores principales:

1. **`postgres` (Base de Datos):**
   - Contenedor basado en `postgres:16-alpine`.
   - Expone el puerto `5432`.
   - Credenciales por defecto: `restaurant` / `secret`.
   - Base de datos por defecto: `restaurant_db`.
   - El volumen de datos (`pg_data`) asegura la persistencia de los registros (mesas y órdenes).

2. **`order-service` (Backend en Rust):**
   - Expone la API RESTful y el servicio de WebSockets en el puerto `3001`.
   - Se conecta automáticamente a `postgres:5432` utilizando la variable de entorno `DATABASE_URL`.
   - Implementa políticas CORS (Configurado por defecto para permitir acceso desde `http://localhost:3000` o variables en `CORS_ORIGIN`).
   - Mantiene un pool de conexiones con PostgreSQL gracias a `sqlx`.

*(Nota: Además existe una definición base para el frontend bajo el servicio `restaurant-front` orquestado también vía Docker).*

## 🚀 Cómo Empezar (Levantar el proyecto)

Asegúrate de tener [Docker](https://docs.docker.com/get-docker/) y [Docker Compose](https://docs.docker.com/compose/install/) instalados.

1. **Clona el repositorio**
   ```bash
   git clone https://github.com/elvicticor/Back-restaurant-with-docker.git
   cd Back-restaurant-with-docker
   ```

2. **Levanta los contenedores**
   ```bash
   docker-compose up --build -d
   ```
   *Esto construirá la imagen de Rust, levantará la base de datos, correrá las migraciones automáticamente con `sqlx` (creando las tablas de órdenes, mesas e ingredientes) y finalmente dejará el servicio escuchando en el puerto 3001.*

3. **Verifica que el servicio esté corriendo**
   Realiza una petición a:
   ```
   GET http://localhost:3001/health
   # Respuesta esperada: OK
   ```

## 📡 API Endpoints

Las rutas principales están divididas en dominios clave:

### 1. Mesas (`Tables`)
- **`GET /tables`**
  Lista las 20 mesas registradas y su estado actual.
- **`PATCH /tables/:id/status`**
  Útil para cambiar el estado de la mesa (`available`, `occupied`, `attention_required`).
  *Validación:* No permite asignar ("occupied") una mesa que ya está ocupada (Retornará `409 Conflict`).

### 2. Órdenes (`Orders`)
- **`POST /orders`**
  Crea un nuevo pedido. Requiere número de mesa, ID de mesero y lista de productos con ingredientes/cantidades.
- **`GET /orders/active`**
  Recupera los pedidos no pagados (vital para la visualización en cocina).
- **`GET /orders/:id`**
  Retorna detalles extendidos de una orden específica.
- **`PATCH /orders/:id/status`**
  Avanza el estado de una orden.

### 3. Facturación (`Billing`)
- **`POST /billing/pay/:table_id`**
  Cierra la cuenta de una mesa: Marca las órdenes de esa mesa como `paid`, calcula subtotales, recargos/impuestos, devuelve el reporte de factura, y libera la mesa poniéndola en `available`.

### 4. Cocina (`Kitchen`)
- **`POST /kitchen/congested`**
  Activa o desactiva la alerta de "cocina congestionada", vital para que los meseros sepan el flujo del restaurante.

## 🔌 Notificaciones en Tiempo Real (WebSockets)

Para conectarse, los clientes web (Frontend) se deben conectar a:
**`ws://localhost:3001/ws`**

El servidor transmite eventos asíncronos en formato JSON que pueden ser interceptados para reaccionar fluidamente sin necesidad de refrescar pantallas. Los tipos de eventos (`type`) emitidos son:

- **`TABLE_UPDATE`**: Emitido cuando una mesa cambia de estado.
- **`ORDER_UPDATE`**: Emitido cuando se crea una nueva orden, cuando su estado avanza en cocina (ej: Preparando -> Listo) o cuando es pagada.
- **`KITCHEN_CONGESTED`**: Emitido con campo booleano para indicar alta latencia en cocina.

## 💡 Modo de Desarrollo Local

Si deseas correr el backend de forma nativa sin Docker:

1. Levanta solo la base de datos.
   ```bash
   docker-compose up postgres -d
   ```
2. Entra a la carpeta de `order-service` y corre el servicio cargando sus dependencias vía Cargo.
   ```bash
   cd order-service
   cargo run
   ```
