export type TableStatus = 'available' | 'occupied' | 'attention_required'

export interface Table {
  id: number
  capacity: number
  status: TableStatus
}

export type OrderStatus = 'pending' | 'preparing' | 'ready' | 'paid'

export interface OrderItem {
  product_id: string
  name?: string
  qty: number
  notes?: string
}

export interface Order {
  id: string
  table_id: number
  waiter_id: string
  status: OrderStatus
  created_at?: string
  items: OrderItem[]
}

export interface BillLine {
  name: string
  qty: number
  unit_price: number
  total: number
}

export interface BillReport {
  table_id: number
  subtotal: number
  tax: number
  total: number
  lines: BillLine[]
}

export type WsEvent =
  | { type: 'TABLE_UPDATE'; payload: Table }
  | { type: 'ORDER_UPDATE'; payload: Order }
  | { type: 'KITCHEN_CONGESTED'; payload: { congested: boolean } }
