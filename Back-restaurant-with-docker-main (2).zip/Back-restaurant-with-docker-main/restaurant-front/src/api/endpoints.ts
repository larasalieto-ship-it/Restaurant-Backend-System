import { api } from './client'
import type { BillReport, Order, Table, TableStatus } from '../types/domain'

export const endpoints = {
  health: () => api<string>('/health'),

  // Tables
  listTables: () => api<Table[]>('/tables'),
  setTableStatus: (id: number, status: TableStatus) =>
    api<Table>(`/tables/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),

  // Orders
  createOrder: (payload: unknown) =>
    api<Order>('/orders', { method: 'POST', body: JSON.stringify(payload) }),
  activeOrders: () => api<Order[]>('/orders/active'),
  getOrder: (id: string) => api<Order>(`/orders/${id}`),
  advanceOrderStatus: (id: string, status: string) =>
    api<Order>(`/orders/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),

  // Billing
  payTable: (tableId: number) => api<BillReport>(`/billing/pay/${tableId}`, { method: 'POST' }),

  // Kitchen
  setCongested: (congested: boolean) =>
    api<{ congested: boolean }>('/kitchen/congested', {
      method: 'POST',
      body: JSON.stringify({ congested }),
    }),
}
