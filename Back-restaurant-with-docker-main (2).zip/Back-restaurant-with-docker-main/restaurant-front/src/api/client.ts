const API_BASE = import.meta.env.VITE_API_BASE ?? 'http://localhost:3001'

export class ApiError extends Error {
  status: number
  body?: unknown
  constructor(message: string, status: number, body?: unknown) {
    super(message)
    this.status = status
    this.body = body
  }
}

async function parseJsonSafe(res: Response) {
  const text = await res.text()
  if (!text) return undefined
  try {
    return JSON.parse(text)
  } catch {
    return text
  }
}

export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
    },
    ...init,
  })

  if (!res.ok) {
    const body = await parseJsonSafe(res)
    throw new ApiError(`API ${res.status} on ${path}`, res.status, body)
  }

  // some endpoints can be plain text
  const contentType = res.headers.get('content-type') ?? ''
  if (contentType.includes('application/json')) {
    return (await res.json()) as T
  }
  return (await res.text()) as unknown as T
}

export function wsUrl(): string {
  // backend says ws://localhost:3001/ws
  const base = API_BASE.replace(/^http/, 'ws')
  return `${base}/ws`
}
