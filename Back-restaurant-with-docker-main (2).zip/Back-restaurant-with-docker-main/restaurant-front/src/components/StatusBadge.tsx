export function StatusBadge({ kind }: { kind: 'ok' | 'warn' | 'bad'; children?: React.ReactNode }) {
  return <span className={`badge ${kind}`}>{kind.toUpperCase()}</span>
}

export function TableStatusBadge({ status }: { status: string }) {
  const kind = status === 'available' ? 'ok' : status === 'occupied' ? 'warn' : 'bad'
  return <span className={`badge ${kind}`}>{status.replace('_', ' ')}</span>
}

export function OrderStatusBadge({ status }: { status: string }) {
  const kind = status === 'ready' ? 'ok' : status === 'preparing' ? 'warn' : status === 'paid' ? 'ok' : 'bad'
  return <span className={`badge ${kind}`}>{status}</span>
}
