import { NavLink } from 'react-router-dom'

const linkStyle: React.CSSProperties = {
  textDecoration: 'none',
  padding: '10px 12px',
  borderRadius: 12,
  border: '1px solid var(--border)',
  background: 'rgba(255,255,255,.03)',
}

export function Nav() {
  return (
    <div className="row" style={{ justifyContent: 'space-between', marginBottom: 16 }}>
      <div>
        <div className="h1">Restaurant System</div>
        <div className="h2">Waiter & Chef dashboards</div>
      </div>
      <div className="row" style={{ gap: 10, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
        <NavLink to="/" style={linkStyle}>
          Home
        </NavLink>
        <NavLink to="/waiter" style={linkStyle}>
          Camarero
        </NavLink>
        <NavLink to="/chef" style={linkStyle}>
          Chef
        </NavLink>
      </div>
    </div>
  )
}
