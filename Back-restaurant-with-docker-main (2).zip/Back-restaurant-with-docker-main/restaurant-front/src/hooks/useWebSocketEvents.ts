import { useEffect, useRef, useState } from 'react'
import { wsUrl } from '../api/client'
import type { WsEvent } from '../types/domain'

export function useWebSocketEvents() {
  const [connected, setConnected] = useState(false)
  const [lastEvent, setLastEvent] = useState<WsEvent | null>(null)
  const wsRef = useRef<WebSocket | null>(null)

  useEffect(() => {
    const ws = new WebSocket(wsUrl())
    wsRef.current = ws

    ws.onopen = () => setConnected(true)
    ws.onclose = () => setConnected(false)
    ws.onerror = () => setConnected(false)

    ws.onmessage = (msg) => {
      try {
        const parsed = JSON.parse(msg.data) as WsEvent
        setLastEvent(parsed)
      } catch {
        // ignore
      }
    }

    return () => {
      ws.close()
    }
  }, [])

  return { connected, lastEvent }
}
