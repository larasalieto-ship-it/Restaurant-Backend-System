import { Route, Routes } from 'react-router-dom'
import { Nav } from './components/Nav'
import Home from './pages/Home'
import Waiter from './pages/Waiter'
import Chef from './pages/Chef'

export default function App() {
  return (
    <div className="container">
      <Nav />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/waiter" element={<Waiter />} />
        <Route path="/chef" element={<Chef />} />
      </Routes>
    </div>
  )
}
