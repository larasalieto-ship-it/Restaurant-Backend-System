import { useEffect, useMemo, useState } from 'react'
import { endpoints } from '../api/endpoints'
import type { Order, Table, TableStatus } from '../types/domain'
import { TableStatusBadge } from '../components/StatusBadge'
import { useWebSocketEvents } from '../hooks/useWebSocketEvents'

function statusNext(status: TableStatus): TableStatus {
  if (status === 'available') return 'occupied'
  if (status === 'occupied') return 'attention_required'
  return 'available'
}

export default function Waiter() {
  const [tables, setTables] = useState<Table[]>([])
  const [activeOrders, setActiveOrders] = useState<Order[]>([])
  const [waiterId, setWaiterId] = useState('server-01')
  const [selectedTable, setSelectedTable] = useState<number>(1)
  const [itemsRaw, setItemsRaw] = useState('burger:1\nfries:1')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const { lastEvent } = useWebSocketEvents()

  async function refresh() {
    setError(null)
    const [t, o] = await Promise.all([endpoints.listTables(), endpoints.activeOrders()])
    setTables(t)
    setActiveOrders(o)
  }

  useEffect(() => {
    refresh().catch((e) => setError(String(e)))
  }, [])

  // Apply realtime events locally
  useEffect(() => {
    if (!lastEvent) return
    if (lastEvent.type === 'TABLE_UPDATE') {
      setTables((prev) => prev.map((x) => (x.id === lastEvent.payload.id ? lastEvent.payload : x)))
    }
    if (lastEvent.type === 'ORDER_UPDATE') {
      setActiveOrders((prev) => {
        const idx = prev.findIndex((x) => x.id === lastEvent.payload.id)
        if (idx === -1) return [lastEvent.payload, ...prev]
        const next = [...prev]
        next[idx] = lastEvent.payload
        return next
      })
    }
  }, [lastEvent])

  const tableById = useMemo(() => new Map(tables.map((t) => [t.id, t])), [tables])

  async function toggleTable(t: Table) {
    setLoading(true)
    setError(null)
    try {
      const next = statusNext(t.status)
      const updated = await endpoints.setTableStatus(t.id, next)
      setTables((prev) => prev.map((x) => (x.id === t.id ? updated : x)))
    } catch (e) {
      setError(String(e))
    } finally {
      setLoading(false)
    }
  }

  async function createOrder() {
    setLoading(true)
    setError(null)
    try {
      const items = itemsRaw
        .split('\n')
        .map((l) => l.trim())
        .filter(Boolean)
        .map((line) => {
          const [product_id, qtyStr] = line.split(':')
          return { product_id: product_id.trim(), qty: Number(qtyStr ?? 1) || 1 }
        })

      const payload = {
        table_id: selectedTable,
        waiter_id: waiterId,
        items,
      }

      const created = await endpoints.createOrder(payload)
      setActiveOrders((prev) => [created, ...prev])
    } catch (e) {
      setError(String(e))
    } finally {
      setLoading(false)
    }
  }

  async function pay(tableId: number) {
    setLoading(true)
    setError(null)
    try {
      const bill = await endpoints.payTable(tableId)
      alert(`Paid table ${bill.table_id}. Total: ${bill.total}`)
      await refresh()
    } catch (e) {
      setError(String(e))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="grid" style={{ gap: 12 }}>
      <div className="card">
        <div className="row" style={{ justifyContent: 'space-between', flexWrap: 'wrap' }}>
          <div>
            <div className="h1">Rol Camarero</div>
            <div className="small">Mesas, atención, pedidos y facturación</div>
          </div>
          <div className="row" style={{ gap: 8 }}>
            <button className="btn" onClick={() => refresh()} disabled={loading}>
              Refresh
            </button>
            <span className={`badge ${error ? 'bad' : 'ok'}`}>{error ? 'Error' : 'Live'}</span>
          </div>
        </div>
        {error && (
          <div className="hr" />
        )}
        {error && <pre style={{ whiteSpace: 'pre-wrap', margin: 0 }}>{error}</pre>}
      </div>

      <div className="grid grid-2">
        <div className="card">
          <div className="h1">Mesas</div>
          <div className="small">Click una mesa para rotar estado: available → occupied → attention_required</div>
          <div className="hr" />
          <div className="tableGrid">
            {tables.map((t) => (
              <button key={t.id} className="tableTile" onClick={() => toggleTable(t)} disabled={loading}>
                <div className="row" style={{ justifyContent: 'space-between' }}>
                  <div className="num">#{t.id}</div>
                  <TableStatusBadge status={t.status} />
                </div>
                <div className="cap">Capacity: {t.capacity}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="h1">Nuevo pedido</div>
          <div className="small">POST /orders</div>
          <div className="hr" />
          <label className="small">Waiter ID</label>
          <input className="input" value={waiterId} onChange={(e) => setWaiterId(e.target.value)} />
          <div style={{ height: 10 }} />
          <label className="small">Mesa</label>
          <select value={selectedTable} onChange={(e) => setSelectedTable(Number(e.target.value))}>
            {tables.map((t) => (
              <option key={t.id} value={t.id}>
                #{t.id} ({t.status})
              </option>
            ))}
          </select>
          <div style={{ height: 10 }} />
          <label className="small">Items (one per line: product_id:qty)</label>
          <textarea
            className="input"
            rows={6}
            value={itemsRaw}
            onChange={(e) => setItemsRaw(e.target.value)}
          />
          <div style={{ height: 10 }} />
          <button className="btn primary" onClick={createOrder} disabled={loading}>
            Send to kitchen
          </button>
          <div className="small" style={{ marginTop: 8 }}>
            Nota: Si tu backend espera otros campos (ej. ingredientes), ajusta el payload en <code>createOrder()</code>.
          </div>
        </div>
      </div>

      <div className="card">
        <div className="row" style={{ justifyContent: 'space-between', flexWrap: 'wrap' }}>
          <div>
            <div className="h1">Órdenes activas</div>
            <div className="small">GET /orders/active</div>
          </div>
        </div>
        <div className="hr" />
        <div className="grid" style={{ gap: 10 }}>
          {activeOrders.length === 0 && <div className="small">No active orders.</div>}
          {activeOrders.map((o) => {
            const t = tableById.get(o.table_id)
            return (
              <div key={o.id} className="card" style={{ background: 'rgba(255,255,255,.02)' }}>
                <div className="row" style={{ justifyContent: 'space-between', flexWrap: 'wrap' }}>
                  <div>
                    <div style={{ fontWeight: 800 }}>Order #{o.id}</div>
                    <div className="small">
                      Table #{o.table_id} · Waiter {o.waiter_id} · Status <b>{o.status}</b>
                    </div>
                    {t && <div className="small">Table state: {t.status}</div>}
                  </div>
                  <div className="row">
                    <button className="btn" onClick={() => pay(o.table_id)} disabled={loading}>
                      Pay table
                    </button>
                  </div>
                </div>
                <div className="hr" />
                <ul style={{ margin: 0, paddingLeft: 18 }}>
                  {o.items?.map((it, idx) => (
                    <li key={idx} className="small">
                      {it.qty}× {it.product_id}
                    </li>
                  ))}
                </ul>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
