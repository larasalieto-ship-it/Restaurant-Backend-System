import { useEffect, useMemo, useState } from 'react'
import { endpoints } from '../api/endpoints'
import type { Order } from '../types/domain'
import { OrderStatusBadge } from '../components/StatusBadge'
import { useWebSocketEvents } from '../hooks/useWebSocketEvents'

const flow = ['pending', 'preparing', 'ready', 'paid'] as const

function nextStatus(status: string) {
  const idx = flow.indexOf(status as any)
  return flow[Math.min(idx + 1, flow.length - 1)]
}

export default function Chef() {
  const [orders, setOrders] = useState<Order[]>([])
  const [congested, setCongested] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const { lastEvent } = useWebSocketEvents()

  async function refresh() {
    setError(null)
    const o = await endpoints.activeOrders()
    setOrders(o)
  }

  useEffect(() => {
    refresh().catch((e) => setError(String(e)))
  }, [])

  useEffect(() => {
    if (!lastEvent) return
    if (lastEvent.type === 'ORDER_UPDATE') {
      setOrders((prev) => {
        const idx = prev.findIndex((x) => x.id === lastEvent.payload.id)
        if (idx === -1) return [lastEvent.payload, ...prev]
        const next = [...prev]
        next[idx] = lastEvent.payload
        return next
      })
    }
    if (lastEvent.type === 'KITCHEN_CONGESTED') {
      setCongested(lastEvent.payload.congested)
    }
  }, [lastEvent])

  const visible = useMemo(() => orders.filter((o) => o.status !== 'paid'), [orders])

  async function bump(order: Order) {
    setLoading(true)
    setError(null)
    try {
      const s = nextStatus(order.status)
      const updated = await endpoints.advanceOrderStatus(order.id, s)
      setOrders((prev) => prev.map((x) => (x.id === order.id ? updated : x)))
    } catch (e) {
      setError(String(e))
    } finally {
      setLoading(false)
    }
  }

  async function toggleCongestion() {
    setLoading(true)
    setError(null)
    try {
      const next = !congested
      await endpoints.setCongested(next)
      setCongested(next)
    } catch (e) {
      setError(String(e))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="grid" style={{ gap: 12 }}>
      <div className="card">
        <div className="row" style={{ justifyContent: 'space-between', flexWrap: 'wrap' }}>
          <div>
            <div className="h1">Rol Chef</div>
            <div className="small">KDS: cola de pedidos + modo congestión</div>
          </div>
          <div className="row" style={{ gap: 8, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
            <button className={`btn ${congested ? 'danger' : 'primary'}`} onClick={toggleCongestion} disabled={loading}>
              {congested ? 'Disable Congestion' : 'Enable Congestion'}
            </button>
            <button className="btn" onClick={() => refresh()} disabled={loading}>
              Refresh
            </button>
            <span className={`badge ${congested ? 'warn' : 'ok'}`}>{congested ? 'High Traffic' : 'Normal'}</span>
          </div>
        </div>
        {error && (
          <>
            <div className="hr" />
            <pre style={{ whiteSpace: 'pre-wrap', margin: 0 }}>{error}</pre>
          </>
        )}
      </div>

      <div className="card">
        <div className="h1">Active queue</div>
        <div className="small">Click “BUMP” to advance: pending → preparing → ready</div>
        <div className="hr" />
        <div className="grid" style={{ gap: 10 }}>
          {visible.length === 0 && <div className="small">No active orders.</div>}
          {visible.map((o) => (
            <div key={o.id} className="card" style={{ background: 'rgba(255,255,255,.02)' }}>
              <div className="row" style={{ justifyContent: 'space-between', flexWrap: 'wrap' }}>
                <div>
                  <div style={{ fontWeight: 800 }}>Table #{o.table_id} · Order #{o.id}</div>
                  <div className="small">Waiter: {o.waiter_id}</div>
                </div>
                <div className="row" style={{ gap: 8 }}>
                  <OrderStatusBadge status={o.status} />
                  <button className="btn primary" onClick={() => bump(o)} disabled={loading || o.status === 'paid'}>
                    BUMP
                  </button>
                </div>
              </div>
              <div className="hr" />
              <ul style={{ margin: 0, paddingLeft: 18 }}>
                {o.items?.map((it, idx) => (
                  <li key={idx} className="small">
                    {it.qty}× {it.product_id}
                    {it.notes ? ` — ${it.notes}` : ''}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
