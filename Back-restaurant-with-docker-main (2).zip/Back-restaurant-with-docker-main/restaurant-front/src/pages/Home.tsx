import { useEffect, useState } from 'react'
import { endpoints } from '../api/endpoints'
import { useWebSocketEvents } from '../hooks/useWebSocketEvents'

export default function Home() {
  const [health, setHealth] = useState<string>('...')
  const [err, setErr] = useState<string | null>(null)
  const { connected, lastEvent } = useWebSocketEvents()

  useEffect(() => {
    endpoints
      .health()
      .then(setHealth)
      .catch((e) => setErr(String(e)))
  }, [])

  return (
    <div className="grid" style={{ gap: 12 }}>
      <div className="card">
        <div className="kpi">
          <div>
            <div className="h1">Backend status</div>
            <div className="small">GET /health</div>
          </div>
          <span className={`badge ${err ? 'bad' : 'ok'}`}>{err ? 'DOWN' : 'UP'}</span>
        </div>
        <div className="hr" />
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <div>
            <div className="small">Response</div>
            <div style={{ fontWeight: 700 }}>{err ?? health}</div>
          </div>
          <div>
            <div className="small">WebSocket</div>
            <div style={{ fontWeight: 700 }}>{connected ? 'Connected' : 'Disconnected'}</div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="h1">Last real-time event</div>
        <div className="small">From ws://.../ws</div>
        <div className="hr" />
        <pre style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{JSON.stringify(lastEvent, null, 2)}</pre>
      </div>

      <div className="card">
        <div className="h1">Config</div>
        <div className="small">
          Set <code>VITE_API_BASE</code> (default: http://localhost:3001)
        </div>
      </div>
    </div>
  )
}
