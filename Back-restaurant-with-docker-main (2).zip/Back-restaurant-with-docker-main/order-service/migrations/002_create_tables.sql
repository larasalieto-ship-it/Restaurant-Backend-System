-- Mesas del restaurante (máximo 20)
CREATE TABLE IF NOT EXISTS restaurant_tables (
    id          INTEGER     PRIMARY KEY CHECK (id BETWEEN 1 AND 20),
    status      TEXT        NOT NULL DEFAULT 'available'
                            CHECK (status IN ('available', 'occupied', 'attention_required')),
    occupied_at TIMESTAMPTZ,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Poblar con las 20 mesas si no existen
INSERT INTO restaurant_tables (id)
SELECT generate_series(1, 20)
ON CONFLICT (id) DO NOTHING;
