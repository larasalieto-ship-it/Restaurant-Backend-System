-- Agrega la columna de ingredientes a cada ítem del pedido.
-- Los ingredientes se almacenan como un arreglo de texto de PostgreSQL.
ALTER TABLE order_items
    ADD COLUMN IF NOT EXISTS ingredients TEXT[] NOT NULL DEFAULT '{}';
