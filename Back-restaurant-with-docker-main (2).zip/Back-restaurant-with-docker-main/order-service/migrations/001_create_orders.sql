-- Tipo ENUM para el estado del pedido
CREATE TYPE order_status AS ENUM ('pending', 'cooking', 'ready', 'paid');

-- Tabla principal de pedidos
CREATE TABLE IF NOT EXISTS orders (
    id           UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    table_number SMALLINT     NOT NULL CHECK (table_number BETWEEN 1 AND 255),
    status       order_status NOT NULL DEFAULT 'pending',
    waiter_id    UUID         NOT NULL,
    created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Tabla de ítems del pedido
CREATE TABLE IF NOT EXISTS order_items (
    id         UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id   UUID          NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id UUID          NOT NULL,
    name       VARCHAR(255)  NOT NULL,
    quantity   INTEGER       NOT NULL CHECK (quantity > 0),
    unit_price NUMERIC(10,4) NOT NULL CHECK (unit_price >= 0),
    tax_rate   NUMERIC(5,4)  NOT NULL CHECK (tax_rate BETWEEN 0 AND 1),
    created_at TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- Índices para consultas frecuentes
CREATE INDEX idx_orders_table_number ON orders(table_number);
CREATE INDEX idx_orders_status       ON orders(status);
CREATE INDEX idx_orders_waiter_id    ON orders(waiter_id);
CREATE INDEX idx_order_items_order   ON order_items(order_id);
