//! Modelo de dominio del agregado `Order`.
//!
//! Reglas de diseño:
//! - Cero dependencias de frameworks (sin Axum, sin SQLx aquí).
//! - Todos los invariantes de negocio se expresan a nivel de tipo o se
//!   validan en los constructores — nunca en capas externas.
//! - Se usa `rust_decimal::Decimal` en lugar de `f64` para evitar errores
//!   de representación en punto flotante en valores monetarios.

use std::str::FromStr;

use chrono::{DateTime, Utc};
use rust_decimal::Decimal;
use serde::{Deserialize, Serialize};
use sqlx::Type;
use uuid::Uuid;

// ══════════════════════════════════════════════════════════════════════════════
// ENUMS
// ══════════════════════════════════════════════════════════════════════════════

/// Estado del ciclo de vida de un pedido.
///
/// Transiciones válidas: `Pending → Cooking → Ready → Paid`
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Type)]
#[sqlx(type_name = "order_status", rename_all = "lowercase")]
#[serde(rename_all = "lowercase")]
pub enum OrderStatus {
    Pending,
    Cooking,
    Ready,
    Paid,
}

impl Default for OrderStatus {
    fn default() -> Self {
        Self::Pending
    }
}

impl std::fmt::Display for OrderStatus {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let s = match self {
            Self::Pending => "pending",
            Self::Cooking => "cooking",
            Self::Ready   => "ready",
            Self::Paid    => "paid",
        };
        f.write_str(s)
    }
}

impl FromStr for OrderStatus {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.to_lowercase().as_str() {
            "pending" => Ok(Self::Pending),
            "cooking" => Ok(Self::Cooking),
            "ready"   => Ok(Self::Ready),
            "paid"    => Ok(Self::Paid),
            other     => Err(format!(
                "Estado inválido: '{other}'. Valores: pending, cooking, ready, paid"
            )),
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// VALUE OBJECTS
// ══════════════════════════════════════════════════════════════════════════════

/// Precio monetario garantizado como no-negativo.
///
/// Usa `Decimal` para evitar errores de punto flotante.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub struct Money(Decimal);

impl Money {
    pub fn new(amount: Decimal) -> Result<Self, String> {
        if amount < Decimal::ZERO {
            Err(format!("El precio no puede ser negativo: {amount}"))
        } else {
            Ok(Self(amount))
        }
    }

    pub fn from_f64(v: f64) -> Result<Self, String> {
        let d = Decimal::try_from(v)
            .map_err(|e| format!("Valor monetario inválido: {e}"))?;
        Self::new(d)
    }

    pub fn value(&self) -> Decimal {
        self.0
    }

    /// Convierte a f64 solo para serialización/presentación.
    pub fn as_f64(&self) -> f64 {
        self.0.try_into().unwrap_or(f64::NAN)
    }
}

impl std::fmt::Display for Money {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{:.4}", self.0)
    }
}

impl std::ops::Add for Money {
    type Output = Self;
    fn add(self, rhs: Self) -> Self {
        Self(self.0 + rhs.0)
    }
}

impl std::ops::Mul<u32> for Money {
    type Output = Self;
    fn mul(self, qty: u32) -> Self {
        Self(self.0 * Decimal::from(qty))
    }
}

impl std::iter::Sum for Money {
    fn sum<I: Iterator<Item = Self>>(iter: I) -> Self {
        iter.fold(Self(Decimal::ZERO), |acc, m| acc + m)
    }
}

// ─────────────────────────────────────────────────────────────────────────────

/// Tasa de impuesto en el rango [0, 1]. Ejemplo: 0.16 → 16 %.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub struct TaxRate(Decimal);

impl TaxRate {
    pub fn new(rate: Decimal) -> Result<Self, String> {
        if !(Decimal::ZERO..=Decimal::ONE).contains(&rate) {
            Err(format!(
                "La tasa de impuesto debe estar entre 0 y 1, se recibió: {rate}"
            ))
        } else {
            Ok(Self(rate))
        }
    }

    pub fn from_f64(v: f64) -> Result<Self, String> {
        let d = Decimal::try_from(v)
            .map_err(|e| format!("Tasa de impuesto inválida: {e}"))?;
        Self::new(d)
    }

    pub fn value(&self) -> Decimal {
        self.0
    }

    pub fn as_f64(&self) -> f64 {
        self.0.try_into().unwrap_or(f64::NAN)
    }
}

// ─────────────────────────────────────────────────────────────────────────────

/// Número de mesa en el rango [1, 255].
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub struct TableNumber(u8);

impl TableNumber {
    pub fn new(n: u8) -> Result<Self, String> {
        if n == 0 {
            Err("El número de mesa debe ser mayor a 0".into())
        } else {
            Ok(Self(n))
        }
    }

    pub fn value(&self) -> u8 {
        self.0
    }
}

impl std::fmt::Display for TableNumber {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}

// ─────────────────────────────────────────────────────────────────────────────

/// Cantidad de un producto — garantiza ≥ 1 a nivel de tipo.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub struct Quantity(std::num::NonZeroU32);

impl Quantity {
    pub fn new(n: u32) -> Result<Self, String> {
        std::num::NonZeroU32::new(n)
            .map(Self)
            .ok_or_else(|| "La cantidad debe ser mayor a 0".into())
    }

    pub fn value(&self) -> u32 {
        self.0.get()
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// ENTITIES
// ══════════════════════════════════════════════════════════════════════════════

/// Ítem dentro de un pedido.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrderItem {
    pub id:          Uuid,
    pub order_id:    Uuid,
    pub product_id:  Uuid,
    pub name:        String,
    pub ingredients: Vec<String>,
    pub quantity:    Quantity,
    pub unit_price:  Money,
    pub tax_rate:    TaxRate,
}

impl OrderItem {
    pub fn new(
        order_id:    Uuid,
        product_id:  Uuid,
        name:        String,
        ingredients: Vec<String>,
        quantity:    u32,
        unit_price:  f64,
        tax_rate:    f64,
    ) -> Result<Self, String> {
        if name.trim().is_empty() {
            return Err("El nombre del producto no puede estar vacío".into());
        }
        Ok(Self {
            id:          Uuid::new_v4(),
            order_id,
            product_id,
            name:        name.trim().to_string(),
            ingredients,
            quantity:    Quantity::new(quantity)?,
            unit_price:  Money::from_f64(unit_price)?,
            tax_rate:    TaxRate::from_f64(tax_rate)?,
        })
    }

    /// Subtotal = precio_unitario × cantidad × (1 + tasa_impuesto).
    pub fn subtotal(&self) -> Money {
        let base   = self.unit_price * self.quantity.value();
        let factor = Decimal::ONE + self.tax_rate.value();
        Money(base.0 * factor)
    }
}

// ─────────────────────────────────────────────────────────────────────────────

/// Agregado raíz `Order`.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Order {
    pub id:           Uuid,
    pub table_number: TableNumber,
    pub status:       OrderStatus,
    pub waiter_id:    Uuid,
    pub items:        Vec<OrderItem>,
    pub created_at:   DateTime<Utc>,
    pub updated_at:   DateTime<Utc>,
}

impl Order {
    /// Crea un pedido nuevo validando todas las invariantes del dominio.
    pub fn new(
        table_number: u8,
        waiter_id:    Uuid,
        items:        Vec<OrderItem>,
    ) -> Result<Self, String> {
        if items.is_empty() {
            return Err("Un pedido debe contener al menos un ítem".into());
        }
        let now = Utc::now();
        Ok(Self {
            id:           Uuid::new_v4(),
            table_number: TableNumber::new(table_number)?,
            status:       OrderStatus::default(),
            waiter_id,
            items,
            created_at:   now,
            updated_at:   now,
        })
    }

    /// Total del pedido: suma de subtotales de todos los ítems.
    pub fn total(&self) -> Money {
        self.items.iter().map(|i| i.subtotal()).sum()
    }

    /// Avanza el estado aplicando reglas de transición de negocio.
    pub fn transition(&mut self, new_status: OrderStatus) -> Result<(), String> {
        use OrderStatus::*;
        let valid = matches!(
            (&self.status, &new_status),
            (Pending, Cooking) | (Cooking, Ready) | (Ready, Paid)
        );
        if !valid {
            return Err(format!(
                "Transición inválida: '{}' → '{}'",
                self.status, new_status
            ));
        }
        self.status     = new_status;
        self.updated_at = Utc::now();
        Ok(())
    }

    pub fn is_closed(&self) -> bool {
        self.status == OrderStatus::Paid
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// TESTS
// ══════════════════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    fn sample_item(order_id: Uuid) -> OrderItem {
        OrderItem::new(order_id, Uuid::new_v4(), "Taco".into(), 2, 45.0, 0.16)
            .expect("ítem válido")
    }

    fn sample_order() -> Order {
        let dummy_id = Uuid::new_v4();
        let item     = sample_item(dummy_id);
        Order::new(5, Uuid::new_v4(), vec![item]).expect("pedido válido")
    }

    #[test]
    fn status_from_str_valid() {
        assert_eq!("cooking".parse::<OrderStatus>().unwrap(), OrderStatus::Cooking);
        assert_eq!("PAID".parse::<OrderStatus>().unwrap(), OrderStatus::Paid);
    }

    #[test]
    fn status_from_str_invalid() {
        assert!("entregado".parse::<OrderStatus>().is_err());
    }

    #[test]
    fn money_rejects_negative() {
        assert!(Money::from_f64(-0.01).is_err());
        assert!(Money::from_f64(0.0).is_ok());
    }

    #[test]
    fn money_sum() {
        let a = Money::from_f64(10.0).unwrap();
        let b = Money::from_f64(5.50).unwrap();
        assert_eq!((a + b).as_f64(), 15.5);
    }

    #[test]
    fn taxrate_rejects_out_of_range() {
        assert!(TaxRate::from_f64(-0.01).is_err());
        assert!(TaxRate::from_f64(1.01).is_err());
        assert!(TaxRate::from_f64(0.16).is_ok());
    }

    #[test]
    fn quantity_rejects_zero() {
        assert!(Quantity::new(0).is_err());
        assert!(Quantity::new(1).is_ok());
    }

    #[test]
    fn table_number_rejects_zero() {
        assert!(TableNumber::new(0).is_err());
        assert!(TableNumber::new(1).is_ok());
    }

    #[test]
    fn item_subtotal_correct() {
        let item = OrderItem::new(
            Uuid::new_v4(), Uuid::new_v4(),
            "Taco".into(), 3, 45.0, 0.16,
        )
        .unwrap();
        // 3 × 45 × 1.16 = 156.60
        let expected = Decimal::try_from(156.6f64).unwrap();
        assert_eq!(item.subtotal().value(), expected.round_dp(10));
    }

    #[test]
    fn item_rejects_empty_name() {
        assert!(
            OrderItem::new(Uuid::new_v4(), Uuid::new_v4(), "  ".into(), 1, 10.0, 0.0).is_err()
        );
    }

    #[test]
    fn order_rejects_empty_items() {
        assert!(Order::new(3, Uuid::new_v4(), vec![]).is_err());
    }

    #[test]
    fn order_transition_valid() {
        let mut order = sample_order();
        assert!(order.transition(OrderStatus::Cooking).is_ok());
        assert!(order.transition(OrderStatus::Ready).is_ok());
        assert!(order.transition(OrderStatus::Paid).is_ok());
        assert!(order.is_closed());
    }

    #[test]
    fn order_transition_invalid() {
        let mut order = sample_order();
        assert!(order.transition(OrderStatus::Paid).is_err());
        assert!(order.transition(OrderStatus::Pending).is_err());
    }

    #[test]
    fn order_total_aggregates_items() {
        let order = sample_order();
        // 2 × 45.0 × 1.16 = 104.40
        let total = order.total().as_f64();
        assert!((total - 104.4).abs() < 1e-9);
    }
}
