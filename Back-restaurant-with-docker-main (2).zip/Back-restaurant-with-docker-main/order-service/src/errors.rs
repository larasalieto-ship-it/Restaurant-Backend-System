use thiserror::Error;
use uuid::Uuid;

#[derive(Debug, Error)]
pub enum AppError {
    #[error("Validación: {0}")]
    Validation(String),

    #[error("Pedido {0} no encontrado")]
    NotFound(Uuid),

    #[error("Error de base de datos")]
    Database(#[from] sqlx::Error),

    #[error("Error interno: {0}")]
    Internal(String),
}
