use std::sync::Arc;

use axum::{
    Json, Router,
    extract::{
        Path, State,
        ws::{Message, WebSocket, WebSocketUpgrade},
    },
    http::{HeaderValue, Method, StatusCode, header},
    response::{IntoResponse, Response},
    routing::{get, patch, post},
};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use sqlx::PgPool;
use sqlx::postgres::PgPoolOptions;
use tokio::sync::broadcast;
use tower_http::{cors::CorsLayer, trace::TraceLayer};
use tracing::info;
use tracing_subscriber::{EnvFilter, fmt};
use uuid::Uuid;

mod config;
mod domain;
mod errors;
mod infrastructure;

use config::Config;
use domain::order::{Order, OrderItem, OrderStatus};
use errors::AppError;
use infrastructure::order_repository::OrderRepository;

// ══════════════════════════════════════════════════════════════════════════════
// ESTADO COMPARTIDO
// ══════════════════════════════════════════════════════════════════════════════

#[derive(Clone)]
struct AppState {
    repo: Arc<OrderRepository>,
    pool: PgPool,
    tx:   broadcast::Sender<String>, // eventos JSON para WebSocket
}

// ══════════════════════════════════════════════════════════════════════════════
// MODELOS DE MESA
// ══════════════════════════════════════════════════════════════════════════════

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
struct RestaurantTable {
    id:          i32,
    status:      String,
    occupied_at: Option<chrono::DateTime<chrono::Utc>>,
    updated_at:  chrono::DateTime<chrono::Utc>,
}

#[derive(Deserialize)]
struct UpdateTableRequest {
    /// Valores: "available" | "occupied" | "attention_required"
    status: String,
}

// ══════════════════════════════════════════════════════════════════════════════
// DTOs DE ORDEN
// ══════════════════════════════════════════════════════════════════════════════

#[derive(Deserialize)]
struct CreateOrderRequest {
    table_number: u8,
    waiter_id:    Uuid,
    items:        Vec<CreateItemRequest>,
}

#[derive(Deserialize)]
struct CreateItemRequest {
    product_id:  Uuid,
    name:        String,
    #[serde(default)]
    ingredients: Vec<String>,
    quantity:    u32,
    unit_price:  f64,
    tax_rate:    f64,
}

#[derive(Deserialize)]
struct UpdateStatusRequest {
    status: String,
}

#[derive(Serialize, Clone)]
struct OrderResponse {
    id:           Uuid,
    table_number: u8,
    status:       String,
    waiter_id:    Uuid,
    items:        Vec<ItemResponse>,
    total:        f64,
    created_at:   String,
    updated_at:   String,
}

#[derive(Serialize, Clone)]
struct ItemResponse {
    id:          Uuid,
    product_id:  Uuid,
    name:        String,
    ingredients: Vec<String>,
    quantity:    u32,
    unit_price:  f64,
    tax_rate:    f64,
    subtotal:    f64,
}

#[derive(Serialize)]
struct ApiResponse<T: Serialize> {
    success: bool,
    data:    T,
}

#[derive(Serialize)]
struct ApiError {
    success: bool,
    error:   String,
    code:    u16,
}

#[derive(Serialize)]
struct BillResponse {
    table_id: i32,
    orders:   Vec<OrderResponse>,
    subtotal: f64,
    tax:      f64,
    total:    f64,
}

// ══════════════════════════════════════════════════════════════════════════════
// EVENTOS WEBSOCKET
// ══════════════════════════════════════════════════════════════════════════════

#[derive(Serialize, Clone)]
#[serde(tag = "type", rename_all = "SCREAMING_SNAKE_CASE")]
enum WsEvent {
    TableUpdate      { table:     RestaurantTable },
    OrderUpdate      { order:     OrderResponse  },
    KitchenCongested { congested: bool           },
}

fn broadcast_event(tx: &broadcast::Sender<String>, event: WsEvent) {
    if let Ok(json) = serde_json::to_string(&event) {
        let _ = tx.send(json);
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// CONVERSIONES
// ══════════════════════════════════════════════════════════════════════════════

impl From<Order> for OrderResponse {
    fn from(o: Order) -> Self {
        let total = o.total().as_f64();
        Self {
            id:           o.id,
            table_number: o.table_number.value(),
            status:       o.status.to_string(),
            waiter_id:    o.waiter_id,
            total,
            items: o.items.into_iter().map(|i| {
                let subtotal = i.subtotal().as_f64();
                ItemResponse {
                    id:          i.id,
                    product_id:  i.product_id,
                    name:        i.name,
                    ingredients: i.ingredients,
                    quantity:    i.quantity.value(),
                    unit_price:  i.unit_price.as_f64(),
                    tax_rate:    i.tax_rate.as_f64(),
                    subtotal,
                }
            }).collect(),
            created_at: o.created_at.to_rfc3339(),
            updated_at: o.updated_at.to_rfc3339(),
        }
    }
}

impl IntoResponse for AppError {
    fn into_response(self) -> Response {
        let (status, msg) = match &self {
            AppError::Validation(m) => (StatusCode::UNPROCESSABLE_ENTITY, m.clone()),
            AppError::NotFound(id)  => (StatusCode::NOT_FOUND, format!("Pedido {id} no encontrado")),
            AppError::Database(e)   => (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()),
            AppError::Internal(m)   => (StatusCode::INTERNAL_SERVER_ERROR, m.clone()),
        };
        (status, Json(ApiError { success: false, error: msg, code: status.as_u16() })).into_response()
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// HANDLER — HEALTH
// ══════════════════════════════════════════════════════════════════════════════

async fn health() -> &'static str { "OK" }

// ══════════════════════════════════════════════════════════════════════════════
// HANDLER — WEBSOCKET
// ══════════════════════════════════════════════════════════════════════════════

async fn ws_handler(
    ws:           WebSocketUpgrade,
    State(state): State<AppState>,
) -> Response {
    ws.on_upgrade(move |socket| handle_ws(socket, state.tx.subscribe()))
}

async fn handle_ws(
    mut socket: WebSocket,
    mut rx:     broadcast::Receiver<String>,
) {
    loop {
        tokio::select! {
            msg = rx.recv() => match msg {
                Ok(json) => {
                    if socket.send(Message::Text(json)).await.is_err() { break; }
                }
                Err(broadcast::error::RecvError::Lagged(_)) => continue,
                Err(_) => break,
            },
            msg = socket.recv() => match msg {
                Some(Ok(Message::Close(_))) | None => break,
                _ => {}
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// HANDLERS — MESAS
// ══════════════════════════════════════════════════════════════════════════════

/// GET /tables — Lista las 20 mesas con su estado actual
async fn get_tables(
    State(state): State<AppState>,
) -> Result<impl IntoResponse, AppError> {
    let tables = sqlx::query_as::<_, RestaurantTable>(
        "SELECT id, status, occupied_at, updated_at FROM restaurant_tables ORDER BY id"
    )
    .fetch_all(&state.pool)
    .await
    .map_err(AppError::Database)?;

    Ok(Json(ApiResponse { success: true, data: tables }))
}

/// PATCH /tables/:id/status — Cambia el estado de una mesa.
/// Previene doble-asignación: no permite marcar como "occupied" una mesa
/// que ya está ocupada (retorna 409 Conflict).
async fn update_table_status(
    State(state): State<AppState>,
    Path(id):     Path<i32>,
    Json(req):    Json<UpdateTableRequest>,
) -> Result<impl IntoResponse, AppError> {
    let valid = ["available", "occupied", "attention_required"];
    if !valid.contains(&req.status.as_str()) {
        return Err(AppError::Validation(format!(
            "Estado inválido: '{}'. Valores: available, occupied, attention_required",
            req.status
        )));
    }

    // Para "occupied": el WHERE excluye mesas ya ocupadas → previene doble asignación.
    // Para otros estados: actualiza sin restricción adicional.
    let table = match req.status.as_str() {
        "occupied" => sqlx::query_as::<_, RestaurantTable>(
            r#"UPDATE restaurant_tables
               SET status = 'occupied', occupied_at = NOW(), updated_at = NOW()
               WHERE id = $1 AND status != 'occupied'
               RETURNING id, status, occupied_at, updated_at"#
        )
        .bind(id)
        .fetch_optional(&state.pool)
        .await
        .map_err(AppError::Database)?
        .ok_or_else(|| AppError::Validation(
            format!("Mesa {id} no encontrada o ya está ocupada")
        ))?,

        _ => sqlx::query_as::<_, RestaurantTable>(
            r#"UPDATE restaurant_tables
               SET status = $1, occupied_at = NULL, updated_at = NOW()
               WHERE id = $2
               RETURNING id, status, occupied_at, updated_at"#
        )
        .bind(&req.status)
        .bind(id)
        .fetch_optional(&state.pool)
        .await
        .map_err(AppError::Database)?
        .ok_or_else(|| AppError::Validation(format!("Mesa {id} no encontrada")))?,
    };

    broadcast_event(&state.tx, WsEvent::TableUpdate { table: table.clone() });
    Ok(Json(ApiResponse { success: true, data: table }))
}

// ══════════════════════════════════════════════════════════════════════════════
// HANDLERS — COCINA
// ══════════════════════════════════════════════════════════════════════════════

/// POST /kitchen/congested — Activa/desactiva alerta de cocina congestionada
async fn kitchen_congested(
    State(state): State<AppState>,
    Json(body):   Json<Value>,
) -> impl IntoResponse {
    let congested = body.get("congested").and_then(|v| v.as_bool()).unwrap_or(false);
    broadcast_event(&state.tx, WsEvent::KitchenCongested { congested });
    Json(ApiResponse { success: true, data: serde_json::json!({ "congested": congested }) })
}

// ══════════════════════════════════════════════════════════════════════════════
// HANDLERS — ÓRDENES
// ══════════════════════════════════════════════════════════════════════════════

/// POST /orders — Crea un pedido con ingredientes por ítem
async fn create_order(
    State(state): State<AppState>,
    Json(req):    Json<CreateOrderRequest>,
) -> Result<impl IntoResponse, AppError> {
    let order_id = Uuid::new_v4();

    let items: Vec<OrderItem> = req
        .items
        .into_iter()
        .map(|i| {
            OrderItem::new(
                order_id,
                i.product_id,
                i.name,
                i.ingredients,
                i.quantity,
                i.unit_price,
                i.tax_rate,
            )
            .map_err(AppError::Validation)
        })
        .collect::<Result<_, _>>()?;

    let mut order = Order::new(req.table_number, req.waiter_id, items)
        .map_err(AppError::Validation)?;
    order.id = order_id;

    let saved = state.repo.create(&order).await?;
    let response: OrderResponse = saved.into();

    broadcast_event(&state.tx, WsEvent::OrderUpdate { order: response.clone() });
    Ok((StatusCode::CREATED, Json(ApiResponse { success: true, data: response })))
}

/// GET /orders/active — Retorna todas las órdenes no pagadas (para la cocina)
async fn get_active_orders(
    State(state): State<AppState>,
) -> Result<impl IntoResponse, AppError> {
    let orders: Vec<OrderResponse> = state.repo
        .find_active_orders()
        .await?
        .into_iter()
        .map(Into::into)
        .collect();
    Ok(Json(ApiResponse { success: true, data: orders }))
}

/// GET /orders/:id — Obtiene un pedido por UUID
async fn get_order(
    State(state): State<AppState>,
    Path(id):     Path<Uuid>,
) -> Result<impl IntoResponse, AppError> {
    let order: OrderResponse = state.repo
        .find_by_id(id)
        .await?
        .ok_or(AppError::NotFound(id))?
        .into();
    Ok(Json(ApiResponse { success: true, data: order }))
}

/// PATCH /orders/:id/status — Avanza el estado de un pedido
async fn update_order_status(
    State(state): State<AppState>,
    Path(id):     Path<Uuid>,
    Json(req):    Json<UpdateStatusRequest>,
) -> Result<impl IntoResponse, AppError> {
    let mut order = state.repo
        .find_by_id(id)
        .await?
        .ok_or(AppError::NotFound(id))?;

    let new_status: OrderStatus = req.status.parse().map_err(AppError::Validation)?;
    order.transition(new_status.clone()).map_err(AppError::Validation)?;

    let updated: OrderResponse = state.repo.update_status(id, &new_status).await?.into();

    broadcast_event(&state.tx, WsEvent::OrderUpdate { order: updated.clone() });
    Ok(Json(ApiResponse { success: true, data: updated }))
}

// ══════════════════════════════════════════════════════════════════════════════
// HANDLER — FACTURACIÓN
// ══════════════════════════════════════════════════════════════════════════════

/// POST /billing/pay/:table_id — Cierra la cuenta de una mesa:
///   1. Obtiene todas las órdenes activas de la mesa para construir la factura.
///   2. Marca dichas órdenes como "paid" en BD.
///   3. Libera la mesa (status → "available", occupied_at → NULL).
///   4. Emite eventos WS de actualización.
///   5. Devuelve el desglose de la factura (subtotal / IVA / total).
async fn pay_table(
    State(state): State<AppState>,
    Path(table_id): Path<i32>,
) -> Result<impl IntoResponse, AppError> {
    // 1. Órdenes activas de la mesa → convertir a DTO para la factura
    let all_active = state.repo.find_active_orders().await?;
    let table_orders: Vec<OrderResponse> = all_active
        .into_iter()
        .filter(|o| o.table_number.value() as i32 == table_id)
        .map(|o| o.into())
        .collect();

    // 2. Marcar órdenes como pagadas (batch update)
    sqlx::query(
        "UPDATE orders SET status = 'paid'::order_status, updated_at = NOW() \
         WHERE table_number = $1 AND status != 'paid'::order_status",
    )
    .bind(table_id as i16)
    .execute(&state.pool)
    .await
    .map_err(AppError::Database)?;

    // 3. Broadcast ORDER_UPDATE para cada orden pagada
    for order in &table_orders {
        let mut paid = order.clone();
        paid.status = "paid".to_string();
        broadcast_event(&state.tx, WsEvent::OrderUpdate { order: paid });
    }

    // 4. Liberar la mesa
    let table = sqlx::query_as::<_, RestaurantTable>(
        r#"UPDATE restaurant_tables
           SET status = 'available', occupied_at = NULL, updated_at = NOW()
           WHERE id = $1
           RETURNING id, status, occupied_at, updated_at"#,
    )
    .bind(table_id)
    .fetch_optional(&state.pool)
    .await
    .map_err(AppError::Database)?
    .ok_or_else(|| AppError::Validation(format!("Mesa {table_id} no encontrada")))?;

    broadcast_event(&state.tx, WsEvent::TableUpdate { table: table.clone() });

    // 5. Calcular desglose fiscal
    let subtotal: f64 = table_orders
        .iter()
        .flat_map(|o| o.items.iter())
        .map(|i| i.unit_price * i.quantity as f64)
        .sum();
    let tax: f64 = table_orders
        .iter()
        .flat_map(|o| o.items.iter())
        .map(|i| i.unit_price * i.quantity as f64 * i.tax_rate)
        .sum();

    Ok(Json(ApiResponse {
        success: true,
        data: BillResponse {
            table_id,
            orders: table_orders,
            subtotal,
            tax,
            total: subtotal + tax,
        },
    }))
}

// ══════════════════════════════════════════════════════════════════════════════
// BOOTSTRAP
// ══════════════════════════════════════════════════════════════════════════════

fn build_cors(allowed_origin: &str) -> CorsLayer {
    // En producción (Docker), el origen es el frontend nginx en :3000.
    // En desarrollo local, Vite corre en :3000 o :5173.
    let origins: Vec<HeaderValue> = [allowed_origin, "http://localhost:5173"]
        .iter()
        .filter_map(|o| o.parse::<HeaderValue>().ok())
        .collect();

    CorsLayer::new()
        .allow_origin(origins)
        .allow_methods([Method::GET, Method::POST, Method::PATCH, Method::OPTIONS])
        .allow_headers([header::CONTENT_TYPE, header::AUTHORIZATION])
        .allow_credentials(false)
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let cfg = Config::from_env().expect("Configuración inválida — revisa DATABASE_URL");

    fmt()
        .with_env_filter(
            EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| EnvFilter::new(&cfg.log_level)),
        )
        .with_target(false)
        .init();

    info!("Iniciando Restaurant Order Service v{}", env!("CARGO_PKG_VERSION"));

    let pool = PgPoolOptions::new()
        .max_connections(20)
        .acquire_timeout(std::time::Duration::from_secs(5))
        .connect(&cfg.database_url)
        .await?;

    sqlx::migrate!("./migrations").run(&pool).await?;
    info!("Migraciones aplicadas (orders + tables + ingredients)");

    let (tx, _) = broadcast::channel::<String>(256);
    let state = AppState {
        repo: Arc::new(OrderRepository::new(pool.clone())),
        pool,
        tx,
    };

    // CORS_ORIGIN se puede configurar vía env; por defecto permite :3000
    let cors_origin = std::env::var("CORS_ORIGIN")
        .unwrap_or_else(|_| "http://localhost:3000".to_string());

    let app = Router::new()
        // Utilidades
        .route("/health",              get(health))
        .route("/ws",                  get(ws_handler))
        // Mesas
        .route("/tables",              get(get_tables))
        .route("/tables/:id/status",   patch(update_table_status))
        // Cocina
        .route("/kitchen/congested",   post(kitchen_congested))
        // Órdenes
        .route("/orders",              post(create_order))
        .route("/orders/active",       get(get_active_orders))
        .route("/orders/:id",          get(get_order))
        .route("/orders/:id/status",   patch(update_order_status))
        // Facturación
        .route("/billing/pay/:table_id", post(pay_table))
        .layer(TraceLayer::new_for_http())
        .layer(build_cors(&cors_origin))
        .with_state(state);

    let addr = format!("{}:{}", cfg.host, cfg.port);
    let listener = tokio::net::TcpListener::bind(&addr).await?;
    info!("Servidor en http://{addr}  |  WS en ws://{addr}/ws  |  CORS → {cors_origin}");

    axum::serve(listener, app).await?;
    Ok(())
}
