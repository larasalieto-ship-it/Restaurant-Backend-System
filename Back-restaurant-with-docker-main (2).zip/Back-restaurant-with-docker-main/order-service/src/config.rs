use std::env;

#[derive(Debug, Clone)]
pub struct Config {
    pub database_url:  String,
    pub host:          String,
    pub port:          u16,
    pub log_level:     String,
}

impl Config {
    /// Carga la configuración desde variables de entorno.
    pub fn from_env() -> Result<Self, String> {
        dotenvy::dotenv().ok(); // archivo .env opcional

        Ok(Self {
            database_url: env_required("DATABASE_URL")?,
            host:         env::var("HOST").unwrap_or_else(|_| "0.0.0.0".into()),
            port:         env::var("PORT")
                .unwrap_or_else(|_| "8080".into())
                .parse()
                .map_err(|_| "PORT debe ser un número válido".to_string())?,
            log_level:    env::var("LOG_LEVEL").unwrap_or_else(|_| "info".into()),
        })
    }
}

fn env_required(key: &str) -> Result<String, String> {
    env::var(key).map_err(|_| format!("Variable de entorno obligatoria no encontrada: {key}"))
}
