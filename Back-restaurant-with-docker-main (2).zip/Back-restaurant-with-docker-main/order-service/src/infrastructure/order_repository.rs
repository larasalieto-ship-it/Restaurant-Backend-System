use rust_decimal::Decimal;
use sqlx::PgPool;
use uuid::Uuid;

use crate::{
    domain::order::{Money, Order, OrderItem, OrderStatus, Quantity, TableNumber, TaxRate},
    errors::AppError,
};

// ── Filas de BD (internal) ─────────────────────────────────────────────────

#[derive(sqlx::FromRow)]
struct OrderRow {
    id:           Uuid,
    table_number: i16,
    status:       String,
    waiter_id:    Uuid,
    created_at:   chrono::DateTime<chrono::Utc>,
    updated_at:   chrono::DateTime<chrono::Utc>,
}

#[derive(sqlx::FromRow)]
struct OrderItemRow {
    id:          Uuid,
    order_id:    Uuid,
    product_id:  Uuid,
    name:        String,
    ingredients: Vec<String>,
    quantity:    i32,
    unit_price:  Decimal,
    tax_rate:    Decimal,
}

// ── Repositorio ────────────────────────────────────────────────────────────

pub struct OrderRepository {
    pool: PgPool,
}

impl OrderRepository {
    pub fn new(pool: PgPool) -> Self {
        Self { pool }
    }

    /// Persiste un pedido y sus ítems dentro de una transacción atómica.
    pub async fn create(&self, order: &Order) -> Result<Order, AppError> {
        let mut tx = self.pool.begin().await?;

        sqlx::query(
            r#"
            INSERT INTO orders (id, table_number, status, waiter_id, created_at, updated_at)
            VALUES ($1, $2, $3::order_status, $4, $5, $6)
            "#,
        )
        .bind(order.id)
        .bind(order.table_number.value() as i16)
        .bind(order.status.to_string())
        .bind(order.waiter_id)
        .bind(order.created_at)
        .bind(order.updated_at)
        .execute(&mut *tx)
        .await?;

        for item in &order.items {
            sqlx::query(
                r#"
                INSERT INTO order_items
                    (id, order_id, product_id, name, ingredients, quantity, unit_price, tax_rate)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                "#,
            )
            .bind(item.id)
            .bind(order.id)
            .bind(item.product_id)
            .bind(item.name.as_str())
            .bind(&item.ingredients)
            .bind(item.quantity.value() as i32)
            .bind(item.unit_price.value())
            .bind(item.tax_rate.value())
            .execute(&mut *tx)
            .await?;
        }

        tx.commit().await?;

        self.find_by_id(order.id)
            .await?
            .ok_or(AppError::NotFound(order.id))
    }

    /// Busca un pedido por ID junto con sus ítems.
    pub async fn find_by_id(&self, id: Uuid) -> Result<Option<Order>, AppError> {
        let row = sqlx::query_as::<_, OrderRow>(
            r#"
            SELECT id, table_number, status::text, waiter_id, created_at, updated_at
            FROM orders
            WHERE id = $1
            "#,
        )
        .bind(id)
        .fetch_optional(&self.pool)
        .await?;

        let Some(row) = row else {
            return Ok(None);
        };

        let item_rows = self.fetch_items(id).await?;
        Ok(Some(map_to_domain(row, item_rows)?))
    }

    /// Lista todos los pedidos de una mesa.
    pub async fn find_by_table(&self, table_number: u8) -> Result<Vec<Order>, AppError> {
        let rows = sqlx::query_as::<_, OrderRow>(
            r#"
            SELECT id, table_number, status::text, waiter_id, created_at, updated_at
            FROM orders
            WHERE table_number = $1
            ORDER BY created_at DESC
            "#,
        )
        .bind(table_number as i16)
        .fetch_all(&self.pool)
        .await?;

        let mut orders = Vec::with_capacity(rows.len());
        for row in rows {
            let id        = row.id;
            let item_rows = self.fetch_items(id).await?;
            orders.push(map_to_domain(row, item_rows)?);
        }
        Ok(orders)
    }

    /// Retorna todos los pedidos activos (no pagados) ordenados por creación.
    pub async fn find_active_orders(&self) -> Result<Vec<Order>, AppError> {
        let rows = sqlx::query_as::<_, OrderRow>(
            r#"
            SELECT id, table_number, status::text, waiter_id, created_at, updated_at
            FROM orders
            WHERE status != 'paid'::order_status
            ORDER BY created_at ASC
            "#,
        )
        .fetch_all(&self.pool)
        .await?;

        let mut orders = Vec::with_capacity(rows.len());
        for row in rows {
            let id        = row.id;
            let item_rows = self.fetch_items(id).await?;
            orders.push(map_to_domain(row, item_rows)?);
        }
        Ok(orders)
    }

    /// Actualiza el estado de un pedido.
    pub async fn update_status(
        &self,
        id: Uuid,
        status: &OrderStatus,
    ) -> Result<Order, AppError> {
        sqlx::query(
            r#"
            UPDATE orders
            SET status = $2::order_status, updated_at = NOW()
            WHERE id = $1
            "#,
        )
        .bind(id)
        .bind(status.to_string())
        .execute(&self.pool)
        .await?;

        self.find_by_id(id)
            .await?
            .ok_or(AppError::NotFound(id))
    }

    async fn fetch_items(&self, order_id: Uuid) -> Result<Vec<OrderItemRow>, AppError> {
        sqlx::query_as::<_, OrderItemRow>(
            r#"
            SELECT id, order_id, product_id, name, ingredients, quantity, unit_price, tax_rate
            FROM order_items
            WHERE order_id = $1
            ORDER BY created_at
            "#,
        )
        .bind(order_id)
        .fetch_all(&self.pool)
        .await
        .map_err(AppError::Database)
    }
}

// ── Mapper ─────────────────────────────────────────────────────────────────

fn map_to_domain(
    row: OrderRow,
    item_rows: Vec<OrderItemRow>,
) -> Result<Order, AppError> {
    let status = row.status.parse::<OrderStatus>().map_err(AppError::Validation)?;

    let items: Vec<OrderItem> = item_rows
        .into_iter()
        .filter_map(|r| {
            let quantity = Quantity::new(r.quantity as u32)
                .map_err(|e| tracing::warn!("Ítem {}: {e}", r.id))
                .ok()?;
            let unit_price = Money::new(r.unit_price)
                .map_err(|e| tracing::warn!("Ítem {}: {e}", r.id))
                .ok()?;
            let tax_rate = TaxRate::new(r.tax_rate)
                .map_err(|e| tracing::warn!("Ítem {}: {e}", r.id))
                .ok()?;
            Some(OrderItem {
                id:          r.id,
                order_id:    r.order_id,
                product_id:  r.product_id,
                name:        r.name,
                ingredients: r.ingredients,
                quantity,
                unit_price,
                tax_rate,
            })
        })
        .collect();

    Ok(Order {
        id:           row.id,
        table_number: TableNumber::new(row.table_number as u8)
            .unwrap_or_else(|_| TableNumber::new(1).unwrap()),
        status,
        waiter_id:    row.waiter_id,
        items,
        created_at:   row.created_at,
        updated_at:   row.updated_at,
    })
}
